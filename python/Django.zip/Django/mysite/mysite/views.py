# This is created by me

# from django.shortcuts import render
from django.http import HttpResponse
from django.urls import path
from django.shortcuts import render

def index(request):
    name = {"first_name": "John", "last_name": "Doe"}
    return render(request, 'index.html',name)
    # return HttpResponse('''<H1>Hello, world. You're at the polls index.</H1> <a href="/about">About</a>''')

def about(request):
    print(request.GET.get("text", "default"))
    return HttpResponse("<H1>About</H1>")