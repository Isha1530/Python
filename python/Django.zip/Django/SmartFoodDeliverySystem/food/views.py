from django.shortcuts import render, get_object_or_404, redirect
from .models import FoodItem, Restaurant, Order
from .forms import FoodItemForm, OrderForm

def fooditem_list(request):
    restaurant_id = request.GET.get('restaurant')
    fooditems = FoodItem.objects.all()
    if restaurant_id:
        fooditems = fooditems.filter(restaurant_id=restaurant_id)
    restaurants = Restaurant.objects.all()
    return render(request, 'food/fooditem_list.html', {'fooditems': fooditems, 'restaurants': restaurants})

def fooditem_create(request):
    if request.method == 'POST':
        form = FoodItemForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('fooditem_list')
    else:
        form = FoodItemForm()
    return render(request, 'food/fooditem_form.html', {'form': form})

def fooditem_update(request, pk):
    fooditem = get_object_or_404(FoodItem, pk=pk)
    form = FoodItemForm(request.POST or None, instance=fooditem)
    if form.is_valid():
        form.save()
        return redirect('fooditem_list')
    return render(request, 'food/fooditem_form.html', {'form': form})

def fooditem_delete(request, pk):
    fooditem = get_object_or_404(FoodItem, pk=pk)
    if request.method == 'POST':
        fooditem.delete()
        return redirect('fooditem_list')
    return render(request, 'food/confirm_delete.html', {'object': fooditem})

def place_order(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('fooditem_list')
    else:
        form = OrderForm()
    return render(request, 'food/order_form.html', {'form': form})

def update_order_status(request, pk):
    order = get_object_or_404(Order, pk=pk)
    form = OrderForm(request.POST or None, instance=order)
    if form.is_valid():
        form.save()
        return redirect('fooditem_list')
    return render(request, 'food/order_form.html', {'form': form})
