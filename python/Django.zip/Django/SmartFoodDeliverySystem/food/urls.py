from django.urls import path
from . import views

urlpatterns = [
    path('', views.fooditem_list, name='fooditem_list'),
    path('food/new/', views.fooditem_create, name='fooditem_create'),
    path('food/<int:pk>/edit/', views.fooditem_update, name='fooditem_update'),
    path('food/<int:pk>/delete/', views.fooditem_delete, name='fooditem_delete'),
    path('order/new/', views.place_order, name='place_order'),
    path('order/<int:pk>/edit/', views.update_order_status, name='update_order_status'),
]
