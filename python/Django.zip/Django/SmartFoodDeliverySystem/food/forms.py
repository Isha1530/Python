from django import forms
from .models import FoodItem, Order

class FoodItemForm(forms.ModelForm):
    class Meta:
        model = FoodItem
        fields = ['name', 'price', 'restaurant']

class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['food_item', 'quantity', 'status']
