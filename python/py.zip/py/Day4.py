#Esacap Sequence character and print statement

# print("Hello guys\ni am \"good\" boy")
# print("hello",end="#")
# print("world")

#data types
# a = None
# print(type(a))
# b = complex(2,3)
# print(type(b))
# print(b)

#calculater

# a = 5
# b = 5
#
# print("The value of" , a , "+" , b ,"is : " ,a+b)
# print("The value of" , a , "-" , b ,"is : " ,a-b)
# print("The value of" , a , "*" , b ,"is : " ,a*b)
# print("The value of" , a , "/" , b ,"is : " ,a/b)
# print("The value of" , a , "//" , b ,"is : " ,a//b)
# print("The value of" , a , "%" , b ,"is : " ,a%b)
# print("The value of" , a , "**" , b ,"is : " ,a**b)

#user input
# a=input()
# print(a)
# print(type(a))

name  = "isha"
print(len(name))