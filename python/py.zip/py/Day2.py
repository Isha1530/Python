# #Logical operator (and,or,not) = used to check if two or more conditional statements is true
from ipykernel.eventloops import loop_qt

# temp = int(input("Enter the number : "))

# if temp>0 and temp<30:
#     print("good temperature!!")
#
# if temp<0 or temp>30:
#     print("bad temperature!!")

# if not(temp == 0):
#     print(" temperature!!")

#loops -- > while = a statement that execute block of code
#           as long as it's condition is true

# for loop
# name = "ISHA"
# for i in name:
#     print(i)
#     if(i == "I"):
#         print("special character")

# for i in range(0,10,2):
#     print(i)

#while loop
# i = int(input("Enter the number : "))
# while i<5:
#     i = int(input("Enter the number : "))
#     print(i)
# print("complete loop ")

#with while loop we can use else
#when while loop condition become falue it is goes inside else block
# i = -1
# while(i>0):
#     print("hello")
# else:
#     print("no loop")

#other type of loop is do while loop
# in do while loop
#always one time loop will executed and then always check condition if it is true then execute
# do{
#
# }while(condition)

#nested loop
# row = int(input("row:"))
# col = int(input("col:"))
# symbol = input("symbol:")
#
# for i in range(row):
#     for j in range(col):
#         print(symbol,end="")
#     print()

#break and continue and pass
# break means terminate the loop
# continue means skip next iteration
# pass use as placeholder , do nothing

# for i in range(1,12):
#     if (i == 10):
#         continue
#     print("5 * " , i ,"=" , 5 * i)
    # if(i == 10):
    #     break

# for i in range(1,10):
#     if(i == 5):
#         pass
#     else:
#         print(i)

